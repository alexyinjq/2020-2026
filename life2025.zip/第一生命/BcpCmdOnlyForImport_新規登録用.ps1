
$server = "ay06t11-msdb.01ab238ce964.database.windows.net"
$database = "[ay06t11-mdb]"
$user = "STG_CRM_USER"
$pwd = "-83aWQz)yX"

$baseDir="G:\ACN\work\ou\20251218\20251222\output"

$imports = @(
    @{Csv= "FRNT_SQL_L2_TOSSUP_out.csv";Fmt="FRNT_SQL_L2_TOSSUP.fmt";Table="[CRM].[FRNT_SQL_L2_TOSSUP]"},
    @{Csv= "FRNT_SQL_L2_KATSUDO_out.csv";Fmt="FRNT_SQL_L2_KATSUDO.fmt";Table="[CRM].[FRNT_SQL_L2_KATSUDO]"}
    
)

foreach($item in $imports){
    write-Host "---------------------------------------------------------------------------------------------------"
    #write-Host "CSV=$($item.Csv) FMT=$($item.Fmt)"
    write-Host "$database.$($item.Table)"
    
    $csvPath = Join-Path $baseDir $item.Csv
    $fmtPath = Join-Path $baseDir $item.Fmt
    
    # if the csv exists
    if(Test-Path $csvPath){
        $args1 = @(
        "$database.$($item.Table)",
        "format",
        "nul",
        "-c",
        "-t", ",",
        "-r", "`n",
        "-f", "$fmtPath",
        "-S", "$server",
        "-U", "$user",
        "-P$pwd")
        #$args1 | ForEach-Object { Write-Host "[$_]" }
        & bcp @args1
        
        $args2 = @(
        "$database.$($item.Table)",
        "in",
        "$csvPath",
        "-f", "$fmtPath",
        "-b", "50000",
        "-h", "TABLOCK",
        "-c",
        "-C", "65001"
        "-t", ",",
        "-S", "$server",
        "-U", "$user",
        "-P$pwd")
        #$args2 | ForEach-Object { Write-Host "[$_]" }
        & bcp @args2
    }
}
