# -*- coding: utf-8 -*-
import csv
import time
from pathlib import Path
from datetime import datetime, timedelta
 
# =========================================================
# BASIC SETTINGS
# =========================================================
BASE_DIR = Path(__file__).parent
TPL = BASE_DIR / "templates"
OUT = BASE_DIR / "output"
OUT.mkdir(exist_ok=True)
 
W = 45000
LOG_STEP = 100_000   
 
# =========================================================
# CSV UTILITIES
# =========================================================
def read_csv(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.reader(f))
 
def read_first_row(path):
    with open(path, encoding="utf-8", newline="") as f:
        return next(csv.reader(f))
 
def zfill(num, width):
    return str(num).zfill(width)
 
# =========================================================
# MAIN GENERATOR
# =========================================================
def gen_C():
    start = now()
 
    tplC = read_csv(TPL / "FRNT_SQL_L2_KATSUDO.csv")[:7]
    tplD = read_csv(TPL / "FRNT_SQL_L2_TOSSUP.csv")

    outC = OUT / "FRNT_SQL_L2_KATSUDO_out.csv"
    outD = OUT / "FRNT_SQL_L2_TOSSUP_out.csv"
 
    seq2 = kikancho = oshirase = csmcount = isscount = 1
    counts = [800, 1, 1, 8, 150, 15, 1025]
 
    totalC = totalD = 0
 
    with open(outC, "w", encoding="utf-8", newline="") as fc, \
         open(outD, "w", encoding="utf-8", newline="") as fd :
 
        wc, wd = map(csv.writer, (fc, fd))

        for z in range(W):
            katsudoday = "2020-08-01"
            StringDate = datetime.strptime(katsudoday, "%Y-%m-%d")
            if z >= 40000:
                for i in range(24000):
                    r = tplC[6].copy()
                    num = (totalC + 2) // 2
                    tt = "TT" + zfill((totalC) // 2000 + 1, 6)
                    tz = "TZ" + zfill((totalC) // 60000 + 1, 6)
                    shu = "9829TT" + zfill(num, 10)
                    kokya = "9829ABCDEFGHIJ" + zfill(num, 10)
                    r[0] = str(totalC + 1)
                    r[2] = shu
                    r[3] = kokya
                    r[4] = tt
                    wc.writerow(r)
                    totalC += 1
            else: 
                for kind in range(7):
                    base = tplC[kind]
                    for _ in range(counts[kind]):
                        N = totalC + 1
                        r = base.copy()
                        r[0] = str(N) 
                        r[11] = StringDate.strftime("%Y-%m-%d")
                        r[26] = (StringDate + timedelta(days = 2)).strftime("%Y-%m-%d")
                        StringDate += timedelta(days = 1)
                        num = (totalC + 2) // 2
                        tt = "TT" + zfill((totalC) // 2000 + 1, 6)
                        tz = "TZ" + zfill((totalC) // 60000 + 1, 6)
                        shu = "9829TT" + zfill(num, 10)
                        kokya = "9829ABCDEFGHIJ" + zfill(num, 10)
                        if kind == 3:
                            r[1] = str(seq2)
                            d = tplD[0].copy()
                            d[0] = seq2
                            d[1] = "CSM" + zfill(csmcount, 15)
                            d[7] = shu
                            d[8] = kokya
                            d[9] = tt
                            d[11] = StringDate.strftime("%Y-%m-%d")
                            wd.writerow(d)
                            totalD += 1
                            csmcount += 1
                            seq2 += 1
                        elif kind == 5:
                            r[1] = str(seq2)
                            d = tplD[1].copy()
                            d[0] = seq2
                            d[1] = str(isscount)
                            d[7] = shu
                            d[8] = kokya
                            d[9] = tt
                            d[11] = StringDate.strftime("%Y-%m-%d")
                            wd.writerow(d)
                            totalD += 1 
                            isscount += 1
                            seq2 += 1
 
                        # ---- C ----
                        r[2] = shu
                        r[3] = kokya
                        r[4] = tt
                    
                        if kind == 0:
                            if N <= 20: c = "01"
                            elif N <= 40: c = "02"
                            elif N <= 50: c = "03"
                            elif N <= 60: c = "04"
                            elif N <= 70: c = "05"
                            elif N <= 770: c = "06"
                            else: c = "07"
                            r[-6] = c
                            if c in ("01","02","03","04","05","07"):
                                r[2] = r[3] = ""
                            if c == "01": r[123] = "222"
                            if c == "02": r[121] = "111"
                            if c == "03": r[122] = "333"
                            if c == "04": r[124] = "1234567890"
                            if c == "05": r[122] = "444"
                            if c == "07": r[47]  = "freeinput"
 
                        wc.writerow(r)
                        totalC += 1
 
            if totalC %  LOG_STEP == 0:
                elapsed = now() - start
                speed = totalC / elapsed
                print(
                        f"C generated: {totalC:,} | "
                        f"{fmt(elapsed)} | "
                        f"{speed:,.0f} rows/s"
                )
 
    elapsed = now() - start
    print("=" * 60)
    print(f"FRNT_SQL_L2_KATSUDO rows: {totalC:,}")
    print(f"FRNT_SQL_L2_TOSSUP:{totalD} ")
    print(f"Elapsed time: {fmt(elapsed)}")
    print(f"Average speed: {totalC / elapsed:,.0f} rows/s")
    print("=" * 60)
# =========================================================
def now():
    return time.perf_counter()
 
def fmt(sec):
    m, s = divmod(int(sec), 60)
    h, m = divmod(m, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"
# =========================================================
if __name__ == "__main__":
    print("=== CSV GENERATION START ===")
    gen_C()
    print("=== ALL DONE ===")
    input("XXXXXXXX")