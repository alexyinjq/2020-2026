--CSV
-- FRNT_SQL_L2_KATSUDO
CREATE NONCLUSTERED INDEX IX_FRNT_SQL_L2_KATSUDO_17 ON CRM.FRNT_SQL_L2_KATSUDO(JUGYOIMBANGO,LAYOUTKUBUNCODE,KATSUDOBI)
CREATE NONCLUSTERED INDEX IX_FRNT_SQL_L2_KATSUDO_18 ON CRM.FRNT_SQL_L2_KATSUDO(LAYOUTKUBUNCODE,KATSUDOBI,STATUS) include(JUGYOIMBANGO)
 
-- FRNT_SQL_L2_KATSUDO_KIKANCHOCOMMENT
CREATE NONCLUSTERED INDEX IX_FRNT_SQL_L2_KATSUDO_KIKANCHOCOMMENT_1
ON CRM.FRNT_SQL_L2_KATSUDO_KIKANCHOCOMMENT (KATSUDOID,KOSHINNICHIJI DESC)
INCLUDE (
    COMMENT,
	REACTIONCODE,
    JUGYOIMBANGO_KIKANCHO,
    SAKUSEINICHIJI
);
 
-- FRNT_SQL_L2_TOSSUPCOMMENT
DROP  INDEX IX_FRNT_SQL_L2_TOSSUPCOMMENT_01 ON FRNT_SQL_L2_TOSSUPCOMMENT (CASESALESFORCEID);
CREATE NONCLUSTERED INDEX IX_FRNT_SQL_L2_TOSSUPCOMMENT_1
ON CRM.FRNT_SQL_L2_TOSSUPCOMMENT (CASESALESFORCEID,KOSHINNICHIJI DESC)
INCLUDE (
    IRAIMOTO,
    REACTIONCODE,
	JUGYOIMBANGO,
    COMMENT,
    SAKUSEINICHIJI
);
 
 
 
 
select i.name as index_name,i.type_desc as index_type,c.name as column_name,ic.key_ordinal,ic.is_included_column
from sys.indexes i join sys.index_columns ic ON i.object_id= ic.object_id and i.index_id = ic.index_id
join sys.all_columns c on ic.object_id = c.object_id and ic.column_id = c.column_id  where i.object_id = OBJECT_ID('CRM.FRNT_SQL_L2_KATSUDO_KIKANCHOCOMMENT')
--DROP INDEX IX_FRNT_SQL_L2_KATSUDO_KIKANCHOCOMMENT_1 ON CRM.FRNT_SQL_L2_KATSUDO_KIKANCHOCOMMENT;
--CREATE NONCLUSTERED INDEX IX_FRNT_SQL_L2_KATSUDO_KIKANCHOCOMMENT_1 ON CRM.FRNT_SQL_L2_KATSUDO_KIKANCHOCOMMENT(KATSUDOID,KOSHINNICHIJI DESC)
--EXEC sp_helpindex 'CRM.FRNT_SQL_L2_KATSUDO_KIKANCHOCOMMENT'
--CREATE NONCLUSTERED INDEX IX_FRNT_SQL_L2_KATSUDO_KIKANCHOCOMMENT_1
--ON CRM.FRNT_SQL_L2_KATSUDO_KIKANCHOCOMMENT (KATSUDOID,KOSHINNICHIJI DESC)
--INCLUDE (
--    COMMENT,
--	REACTIONCODE,
--    JUGYOIMBANGO_KIKANCHO,
--    SAKUSEINICHIJI
--);
 
select i.name as index_name,i.type_desc as index_type,c.name as column_name,ic.key_ordinal,ic.is_included_column
from sys.indexes i join sys.index_columns ic ON i.object_id= ic.object_id and i.index_id = ic.index_id
join sys.all_columns c on ic.object_id = c.object_id and ic.column_id = c.column_id  where i.object_id = OBJECT_ID('CRM.FRNT_SQL_L2_TOSSUPCOMMENT')
 
select i.name as index_name,i.type_desc as index_type,c.name as column_name,ic.key_ordinal,ic.is_included_column
from sys.indexes i join sys.index_columns ic ON i.object_id= ic.object_id and i.index_id = ic.index_id
join sys.all_columns c on ic.object_id = c.object_id and ic.column_id = c.column_id  where i.object_id = OBJECT_ID('CRM.FRNT_SQL_L2_KATSUDO')
DROP INDEX IX_FRNT_SQL_L2_KATSUDO_17 ON CRM.FRNT_SQL_L2_KATSUDO;
CREATE NONCLUSTERED INDEX IX_FRNT_SQL_L2_KATSUDO_17 ON CRM.FRNT_SQL_L2_KATSUDO(JUGYOIMBANGO,LAYOUTKUBUNCODE,KATSUDOBI)
CREATE NONCLUSTERED INDEX IX_FRNT_SQL_L2_KATSUDO_18 ON CRM.FRNT_SQL_L2_KATSUDO(LAYOUTKUBUNCODE,KATSUDOBI,STATUS) include(JUGYOIMBANGO)
select i.name as index_name,i.type_desc as index_type,c.name as column_name,ic.key_ordinal,ic.is_included_column
from sys.indexes i join sys.index_columns ic ON i.object_id= ic.object_id and i.index_id = ic.index_id
join sys.all_columns c on ic.object_id = c.object_id and ic.column_id = c.column_id  where i.object_id = OBJECT_ID('CRM.FRNT_SQL_L2_UIYOKOKYAKUJUGYOINKANKEI')
 
 
select i.name as index_name,i.type_desc as index_type,c.name as column_name,ic.key_ordinal,ic.is_included_column
from sys.indexes i join sys.index_columns ic ON i.object_id= ic.object_id and i.index_id = ic.index_id
join sys.all_columns c on ic.object_id = c.object_id and ic.column_id = c.column_id  where i.object_id = OBJECT_ID('CRM.FRNT_SQL_L2_TOSSUP')
--ALTER TABLE CRM.FRNT_SQL_L2_TOSSUP
--ADD CASESALESFORCEID_BIGINT AS TRY_CAST(CASESALESFORCEID AS BIGINT) PERSISTED;
--DROP INDEX IX_FRNT_SQL_L2_TOSSUP_08 ON CRM.FRNT_SQL_L2_TOSSUP;
--ALTER TABLE CRM.FRNT_SQL_L2_TOSSUP
-- DROP column CASESALESFORCEID_BIGINT;
 
select TOp (1) * from CRM.FRNT_SQL_L2_TOSSUP;
--CREATE INDEX IX_FRNT_SQL_L2_TOSSUP_08
--ON CRM.FRNT_SQL_L2_TOSSUP (CASESALESFORCEID_BIGINT);
 
--CREATE NONCLUSTERED INDEX IX_FRNT_SQL_L2_KATSUDO_17 ON CRM.FRNT_SQL_L2_KATSUDO(JUGYOIMBANGO,LAYOUTKUBUNCODE,KATSUDOBI)
 
	select top 100 DB_NAME(qt.dbid) as database_name
	,qt.text as parent_query
	,SUBSTRING (qt.text, qs.statement_start_offset/2,
	(CASE when qs.statement_end_offset = -1 THEN len(convert(nvarchar(max),
	qt.text)) *2 
	  ELSE qs.statement_end_offset
	  END - qs.statement_start_offset)/2) as statement
	,(qs.total_worker_time/1000) / qs.execution_count as avg_cpu_time_ms
	,(qs.total_elapsed_time/1000) / qs.execution_count as avg_duration_ms
	,(qs.total_physical_reads/1000) / qs.execution_count as avg_physical_reads_ms
	,qs.execution_count as  execution_count
	, last_execution_time
	, creation_time
	,total_worker_time / 1000 as total_CPU_time_ms
	,total_elapsed_time / 1000 as total_duration_time_ms
	,total_physical_reads / 1000 as total_physical_reads_ms
	,qp.query_plan
	from sys.dm_exec_query_stats qs
	  outer apply sys.dm_exec_sql_text(sql_handle) as qt
	  outer apply sys.dm_exec_query_plan(plan_handle) as qp
	where 
	qt.text like '%@PT%' and 
	last_execution_time >= '2026-01-09 10:30:00'
	order by  (qs.total_elapsed_time/qs.execution_count) desc